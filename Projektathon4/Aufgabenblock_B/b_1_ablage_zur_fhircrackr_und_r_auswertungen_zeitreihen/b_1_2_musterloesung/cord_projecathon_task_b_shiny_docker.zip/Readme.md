This repository will contain a deployable version of the cord projectathon task b. 

Docker-Compose

If you want to use the tool via Docker-Compose (which is recommended), you can simply start the application via

`docker-compose up -d`

You can stop the tool via

`docker-compose down`

If code has changed, you can build a new image and start the application via

`docker-compose up --build -d`

Go to Browser and use following URL
`http://localhost:3838/covid/`

Alternative way to start the application

1. Build Docker

`docker build -t my-shiny-app .`

2. Run Docker

`docker run --rm -p 3838:3838 my-shiny-app`

3. Use tool 

Go to Browser and use following URL
`http://localhost:3838/covid/`
