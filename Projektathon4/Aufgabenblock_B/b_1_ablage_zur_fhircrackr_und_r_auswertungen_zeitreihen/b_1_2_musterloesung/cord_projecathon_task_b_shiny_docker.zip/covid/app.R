#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(fhircrackr)

search_request <- paste0(
    'https://mii-agiop-cord.life.uni-leipzig.de/fhir/',
    'Condition?',
    'code=J12.8%20U07.1%21,U08.9%20U09.9%21'
)

# define design 
design <- list(
    Conditions = list(
        resource = "//Condition",
        cols = list(
            condition_id = "id",
            code = "code/coding/code",
            display = "code/coding/display",
            text = "code/text",
            system = "code/coding/system",
            patient_id = "subject/reference",
            encounter_id = "encounter/reference",
            recorded_date = "recordedDate",
            onset_period_start = "onsetPeriod/start",
            onset_period_end = "onsetPeriod/end"
        ),
        style = list(
            sep="|",
            brackets = c("[", "]"),
            rm_empty_cols = FALSE
        )
    )
)

# download fhir bundles
bundles <- fhir_search(request = search_request, max_bundles = 50,verbose =2,log_errors = 2)

# crack fhir bundles
dfs <- fhir_crack(bundles, design)

# save raw conditions dataframe
covid_conditions_raw <- dfs$Conditions

# unnest raw conditions dataframe columns code/coding/code, code/coding/display, code/coding/system
covid_conditions_tmp <- fhir_melt(covid_conditions_raw,
                                  columns = c('code','display','system'),
                                  brackets = c('[',']'), sep = '|', all_columns = TRUE,)
covid_conditions_tmp <- fhir_melt(covid_conditions_tmp,
                                  columns = c('code','display','system'),
                                  brackets = c('[',']'), sep = '|', all_columns = TRUE,)

# remove brackets from cells
covid_conditions_tmp <- fhir_rm_indices(covid_conditions_tmp, brackets = c("[", "]") )

# filter conditions by system = icd-10-gm
covid_conditions_tmp <- covid_conditions_tmp[covid_conditions_tmp$system == 'http://fhir.de/CodeSystem/dimdi/icd-10-gm',]

# remove duplicate patients
covid_conditions <- covid_conditions_tmp[!duplicated(covid_conditions_tmp$patient_id),]

# remove Patient/ from subject/reference and Encounter from encounter/reference
covid_conditions$patient_id <- sub("Patient/", "", covid_conditions[,6])
covid_conditions$encounter_id <- sub("Encounter/", "", covid_conditions[,7])

# separate patient_id into Airolo, Bapu, Cynthia institution_id
covid_conditions$institution_id <- unlist(strsplit(covid_conditions$patient_id,'-P-'))[ c(TRUE,FALSE) ]

tmp_table3 <- data.frame(month=formatC(c(1:12), width=2, flag="0"),Freq=c(1417,1020,1081,871,917,970,969,966,932,872,969,728))
tmp_table4 <- data.frame(month=formatC(c(1:12), width=2, flag="0"),Freq=c(6398,4886,5172,4260,4377,4743,4517,4264,4156,4411,4463,3701))

df_final <- read.csv("../data/df_final.csv", header = FALSE)
df_final <- data.frame(institution_id=df_final[2:length(df_final[,1]),2:2],code=df_final[2:length(df_final[,1]),3:3],display=df_final[2:length(df_final[,1]),4:4],gender=df_final[2:length(df_final[,1]),5:5],age=df_final[2:length(df_final[,1]),6:6],count=as.integer(df_final[2:length(df_final[,1]),7:7]))

# Define UI for application that draws a histogram
ui <- fluidPage(
    
    # Application title
    titlePanel("Projectathon CORD Breakout Task B Covid Time Series\n"),    
    # Sidebar with a slider input for number of bins 
    sidebarLayout(
        sidebarPanel(
            checkboxGroupInput(inputId = "timeSeriesKind", label = "Which kind of time series?", choices = c("ICD_10GM", "Orpha Data", 'J12.8 U07.1!','U08.9 U09.9!'), selected = c('J12.8 U07.1!','U08.9 U09.9!'), inline = F)
        ),

        # Show a plot of the generated distribution
        mainPanel(
            plotOutput("seriesPlot")
            )
        ),
    fluidRow(column(12,dataTableOutput('dto'))
             )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    output$dto <- renderDataTable({df_final})
    library(tidyverse)
    library(ggplot2)
    output$seriesPlot <- renderPlot({
        
        # extract Patient ID and Month for all patients, patients with J12.8 U07.1! and patients with U08.1 U09.9! from DataSet
        pat_month <- data.frame(PID=covid_conditions$patient_id,month = format(as.Date(covid_conditions$recorded_date),'%m'))
        pat_month1 <- data.frame(PID=covid_conditions[covid_conditions$code == 'J12.8 U07.1!',]$patient_id,'J12.8 U07.1!' = format(as.Date(covid_conditions[covid_conditions$code == 'J12.8 U07.1!',]$recorded_date),'%m'))
        pat_month2 <- data.frame(PID=covid_conditions[covid_conditions$code == 'U08.9 U09.9!',]$patient_id,'U08.9 U09.9!' = format(as.Date(covid_conditions[covid_conditions$code == 'U08.9 U09.9!',]$recorded_date),'%m'))
        
        # order data regarding month
        pat_month <- pat_month[order(pat_month$month),]
        pat_month1 <- pat_month1[order(pat_month1$J12.8.U07.1.),]
        pat_month2 <- pat_month2[order(pat_month2$U08.9.U09.9.),]
        
        # counts occurrences of patients per month
        tmp_table <- as.data.frame(table(month=pat_month$month))
        tmp_table1 <- as.data.frame(table(month=pat_month1$J12.8.U07.1.))
        tmp_table2 <- as.data.frame(table(month=pat_month2$U08.9.U09.9.))
        
        # create month vector with 01,02...11,12
        month_vec <- data.frame(month=formatC(c(1:12), width=2, flag="0"))
        
        #join month vector with tmp_table, 1 and 2 and set column names
        tmp_table <- left_join(month_vec,tmp_table, by='month')
        tmp_table <- left_join(tmp_table,tmp_table1, by='month')
        tmp_table <- left_join(tmp_table,tmp_table2, by='month')
        tmp_table <- left_join(tmp_table,tmp_table3, by='month')
        tmp_table <- left_join(tmp_table,tmp_table4, by='month')
        colnames(tmp_table) = c('month', 'summe', 'J12.8','U08.9','orpha','icd')
        
        # fill temp_df with 0s if no occurrence exists in a month 
        tmp_table[is.na(tmp_table)] <- 0
        
        if("ICD_10GM" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind && "J12.8 U07.1!" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind)
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!"))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                geom_line(aes(y=orpha, color="code=all orpha codes"))+
                geom_line(aes(y=icd, color="code=all icd10gm codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if(!("ICD_10GM" %in% input$timeSeriesKind) && "Orpha Data" %in% input$timeSeriesKind && "J12.8 U07.1!" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind)
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!"))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                geom_line(aes(y=orpha, color="code=all orpha codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("ICD_10GM" %in% input$timeSeriesKind && !("Orpha Data" %in% input$timeSeriesKind) && "J12.8 U07.1!" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind)
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!"))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                geom_line(aes(y=icd, color="code=all icd10gm codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("ICD_10GM" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind && !("J12.8 U07.1!" %in% input$timeSeriesKind) && "U08.9 U09.9!" %in% input$timeSeriesKind)
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                geom_line(aes(y=orpha, color="code=all orpha codes"))+
                geom_line(aes(y=icd, color="code=all icd10gm codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("ICD_10GM" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind && "J12.8 U07.1!" %in% input$timeSeriesKind && !("U08.9 U09.9!" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!"))+
                geom_line(aes(y=orpha, color="code=all orpha codes"))+
                geom_line(aes(y=icd, color="code=all icd10gm codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("ICD_10GM" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind && !("J12.8 U07.1!" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=orpha, color="code=all orpha codes"))+
                geom_line(aes(y=icd, color="code=all icd10gm codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if(!("ICD_10GM" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind) && "J12.8 U07.1!" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind)
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!"))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("ICD_10GM" %in% input$timeSeriesKind && "J12.8 U07.1!" %in% input$timeSeriesKind && !("Orpha Data" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!"))+
                geom_line(aes(y=icd, color="code=all icd10gm codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("ICD_10GM" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind && !("J12.8 U07.1!" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                geom_line(aes(y=icd, color="code=all icd10gm codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("J12.8 U07.1!" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind && !("ICD_10GM" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!"))+
                geom_line(aes(y=orpha, color="code=all orpha codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("U08.9 U09.9!" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind && !("J12.8 U07.1!" %in% input$timeSeriesKind && "ICD_10GM" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                geom_line(aes(y=orpha, color="code=all orpha codes"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("ICD_10GM" %in% input$timeSeriesKind && !("Orpha Data" %in% input$timeSeriesKind && "J12.8 U07.1!" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=icd, color="code=all icd10gm codes")) +
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("Orpha Data" %in% input$timeSeriesKind && !("ICD_10GM" %in% input$timeSeriesKind && "J12.8 U07.1!" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=orpha, color="code=all orpha codes")) +
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("J12.8 U07.1!" %in% input$timeSeriesKind && !("ICD_10GM" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind && "U08.9 U09.9!" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=J12.8, color="code=J12.8 U07.1!")) +
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else if("U08.9 U09.9!" %in% input$timeSeriesKind && !("ICD_10GM" %in% input$timeSeriesKind && "J12.8 U07.1!" %in% input$timeSeriesKind && "Orpha Data" %in% input$timeSeriesKind))
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                geom_line(aes(y=U08.9, color="code=U08.9 U09.9!"))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")
        }
        else
        {
            ggplot2::ggplot(tmp_table,aes(x=month, group=1))+
                labs(title = "Diagnoses of Patients by Time\n", x = "Month", y = "Count", color = "Condition\n")    
        }
        
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
